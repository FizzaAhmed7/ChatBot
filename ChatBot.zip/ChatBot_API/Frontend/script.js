// ================= STATE =================
let sessions = JSON.parse(localStorage.getItem("chatSessions")) || [];
let activeSessionIndex = parseInt(localStorage.getItem("activeSessionIndex")) || null;
let isTyping = false;

// ================= DOM =================
const welcomeScreen = document.getElementById('welcomeScreen');
const messagesContainer = document.getElementById('messagesContainer');
const messageInput = document.getElementById('messageInput');
const chatArea = document.getElementById('chatArea');
const chatHistory = document.getElementById('chatHistory');

// Auto-grow textarea
messageInput.addEventListener('input', function () {
  this.style.height = 'auto';
  this.style.height = (this.scrollHeight) + 'px';
});

// Reset height after sending
function resetInputHeight() {
  messageInput.style.height = 'auto';
}

// ================= INIT =================
document.addEventListener("DOMContentLoaded", () => {
  if (sessions.length === 0) {
    startNewChat();
  } else {
    if (activeSessionIndex === null || activeSessionIndex >= sessions.length) {
      activeSessionIndex = sessions.length - 1;
    }
    renderChatHistory();
    renderMessages();
  }
});

// ================= NEW CHAT =================
function startNewChat() {
  sessions.push({ messages: [], title: "New Chat" });
  activeSessionIndex = sessions.length - 1;
  saveCurrentSession();
  renderChatHistory();
  renderMessages();
}

// ================= SAVE SESSION =================
function saveCurrentSession() {
  localStorage.setItem("chatSessions", JSON.stringify(sessions));
  localStorage.setItem("activeSessionIndex", JSON.stringify(activeSessionIndex));
}

// ================= SWITCH SESSION =================
function openSession(index) {
  activeSessionIndex = index;
  saveCurrentSession();
  renderChatHistory();
  renderMessages();
}

// ================= CHAT HISTORY =================
function renderChatHistory() {
  chatHistory.innerHTML = '';
  sessions.forEach((session, i) => {
    const title = session.title || `Chat ${i + 1}`;
    const preview = session.messages.length > 0 ? session.messages[0].content.substring(0, 30) + "..." : "No messages";

    const btn = document.createElement('button');
    btn.className = `chat-item ${i === activeSessionIndex ? 'active' : ''}`;
    btn.innerHTML = `
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
      </svg>
      <div class="chat-item-content">
        <span class="chat-title">${title}</span>
        <span class="chat-date">${session.messages.length} msgs</span>
      </div>
      <button class="delete-chat-btn" onclick="event.stopPropagation(); deleteChat(${i})" title="Delete chat">🗑</button>
    `;
    btn.onclick = () => openSession(i);
    chatHistory.appendChild(btn);
  });
}

// ================= SEND MESSAGE =================
async function sendMessage() {
  if (activeSessionIndex === null) startNewChat();

  const text = messageInput.value.trim();
  if (!text || isTyping) return;

  // Add user message
  sessions[activeSessionIndex].messages.push({ role: "user", content: text });
  messageInput.value = '';
  resetInputHeight();
  renderMessages();
  showTypingIndicator();

  try {
    const response = await fetch("http://127.0.0.1:8000/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(sessions[activeSessionIndex].messages)
    });

    const data = await response.json();
    hideTypingIndicator();

    if (!response.ok || !data.response) {
      addBotMessage("❌ Error: Could not get response from server.");
    } else {
      addBotMessage(data.response);
    }

    // Update chat title if still "New Chat"
    if (sessions[activeSessionIndex].title === "New Chat" && sessions[activeSessionIndex].messages.length > 0) {
      sessions[activeSessionIndex].title = text.substring(0, 30) + (text.length > 30 ? "..." : "");
    }

    saveCurrentSession();
    renderChatHistory();
  } catch (err) {
    hideTypingIndicator();
    addBotMessage("❌ Backend not running or connection error");
    console.error(err);
  }
}

function addBotMessage(text) {
  sessions[activeSessionIndex].messages.push({ role: "assistant", content: text });
  renderMessages();
  saveCurrentSession();
}

// ================= SORTABLE TABLES =================
function makeTablesSortable() {
  document.querySelectorAll('.message.bot .message-bubble table').forEach(table => {
    // Skip if already made sortable
    if (table.dataset.sortable === 'true') return;
    table.dataset.sortable = 'true';

    const headers = table.querySelectorAll('thead th');
    headers.forEach((th, colIndex) => {
      th.style.cursor = 'pointer';
      th.addEventListener('click', () => {
        sortTable(table, colIndex);
      });
    });
  });
}

function sortTable(table, colIndex) {
  const tbody = table.querySelector('tbody');
  if (!tbody) return;

  const rows = Array.from(tbody.querySelectorAll('tr'));

  // Determine direction: first click = asc, same column again = toggle
  const currentDir = table.dataset.sortDir || 'asc';
  const currentCol = table.dataset.sortCol;
  const isSameCol = currentCol === colIndex.toString();
  const direction = (isSameCol && currentDir === 'asc') ? 'desc' : 'asc';

  table.dataset.sortDir = direction;
  table.dataset.sortCol = colIndex.toString();

  rows.sort((rowA, rowB) => {
    const a = rowA.cells[colIndex].textContent.trim();
    const b = rowB.cells[colIndex].textContent.trim();

    // Try to sort as numbers (handles $1,234.56 etc.)
    const aNum = parseFloat(a.replace(/[^0-9.-]/g, ''));
    const bNum = parseFloat(b.replace(/[^0-9.-]/g, ''));

    let comparison;
    if (!isNaN(aNum) && !isNaN(bNum)) {
      comparison = aNum - bNum;
    } else {
      comparison = a.localeCompare(b);
    }

    return direction === 'asc' ? comparison : -comparison;
  });

  // Re-append rows in sorted order
  rows.forEach(row => tbody.appendChild(row));

  // Update arrow indicators
  table.querySelectorAll('th .sort-arrow').forEach(arrow => arrow.remove());
  const header = table.querySelectorAll('thead th')[colIndex];
  const arrow = document.createElement('span');
  arrow.className = 'sort-arrow';
  arrow.textContent = direction === 'asc' ? '▲' : '▼';
  header.appendChild(arrow);
}

// ================= RENDER MESSAGES =================
function renderMessages() {
  if (activeSessionIndex === null || !sessions[activeSessionIndex]) return;

  const msgs = sessions[activeSessionIndex].messages;

  if (msgs.length === 0) {
    welcomeScreen.style.display = 'flex';
    messagesContainer.style.display = 'none';
    return;
  }

  welcomeScreen.style.display = 'none';
  messagesContainer.style.display = 'flex';
  messagesContainer.innerHTML = '';

  for (let i = 0; i < msgs.length; i++) {
    const m = msgs[i];

    const div = document.createElement('div');
    div.className = `message ${m.role === 'user' ? 'user' : 'bot'}`;

    const bubble = document.createElement('div');
    bubble.className = 'message-bubble';

    if (m.role === 'user') {
      const p = document.createElement('p');
      p.innerHTML = escapeHtml(m.content).replace(/\n/g, '<br>');
      bubble.appendChild(p);

      // Edit button (visible on hover)
      const actions = document.createElement('div');
      actions.className = 'message-actions';
      const editBtn = document.createElement('button');
      editBtn.innerHTML = `
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
          <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
        </svg>
      `;
      editBtn.title = "Edit message";
      editBtn.onclick = (e) => {
        e.stopPropagation();
        editMessage(i);
      };
      actions.appendChild(editBtn);
      div.appendChild(actions);
    } else {
      bubble.innerHTML = marked.parse(m.content);
      bubble.querySelectorAll('pre code').forEach(block => {
        hljs.highlightElement(block);
      });
    }

    bubble.innerHTML += `<div class="message-time">${formatTime(new Date())}</div>`;
    div.appendChild(bubble);
    messagesContainer.appendChild(div);
  }

  makeTablesSortable();
  chatArea.scrollTop = chatArea.scrollHeight;
}

// ================= EDIT MESSAGE =================
async function editMessage(msgIndex) {
  const session = sessions[activeSessionIndex];
  const messages = session.messages;
  const originalContent = messages[msgIndex].content;

  const messageDivs = messagesContainer.querySelectorAll('.message');
  const messageDiv = messageDivs[msgIndex];
  if (!messageDiv) return;

  const bubble = messageDiv.querySelector('.message-bubble');
  bubble.innerHTML = '';

  // Textarea for editing
  const textarea = document.createElement('textarea');
  textarea.value = originalContent;
  textarea.className = 'edit-textarea';
  bubble.appendChild(textarea);

  // Save/Cancel buttons
  const controls = document.createElement('div');
  controls.className = 'edit-controls';

  const saveBtn = document.createElement('button');
  saveBtn.textContent = 'Save & Regenerate';
  saveBtn.onclick = async () => {
    const newContent = textarea.value.trim();
    if (!newContent) {
      alert('Message cannot be empty');
      return;
    }

    // Update message
    messages[msgIndex].content = newContent;

    // Remove all messages after this one
    messages.length = msgIndex + 1;

    // Re-render (shows updated user message, removes later ones)
    renderMessages();

    // Get new bot response
    showTypingIndicator();

    try {
      const response = await fetch("http://127.0.0.1:8000/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(messages)
      });

      const data = await response.json();
      hideTypingIndicator();

      if (response.ok && data.response) {
        addBotMessage(data.response);
      } else {
        addBotMessage("❌ Error: Could not generate response.");
      }

      saveCurrentSession();
      renderChatHistory();
    } catch (err) {
      hideTypingIndicator();
      addBotMessage("❌ Connection error");
      console.error(err);
    }
  };

  const cancelBtn = document.createElement('button');
  cancelBtn.textContent = 'Cancel';
  cancelBtn.onclick = () => renderMessages();

  controls.appendChild(saveBtn);
  controls.appendChild(cancelBtn);
  bubble.appendChild(controls);

  textarea.focus();
}

// ================= TYPING INDICATOR =================
function showTypingIndicator() {
  isTyping = true;
  const indicator = document.createElement('div');
  indicator.className = 'message bot';
  indicator.id = 'typingIndicator';
  indicator.innerHTML = `
    <div class="message-bubble">
      <div class="typing-indicator">
        <span class="typing-dot"></span>
        <span class="typing-dot"></span>
        <span class="typing-dot"></span>
      </div>
    </div>`;
  messagesContainer.appendChild(indicator);
  chatArea.scrollTop = chatArea.scrollHeight;
}

function hideTypingIndicator() {
  isTyping = false;
  const indicator = document.getElementById('typingIndicator');
  if (indicator) indicator.remove();
}

// ================= SUGGESTION =================
function sendSuggestion(q) {
  messageInput.value = q;
  sendMessage();
}

// ================= KEYDOWN =================
function handleKeyDown(e) {
  if (e.key === 'Enter' && !e.shiftKey) {
    e.preventDefault();
    sendMessage();
  }
}

// ================= DELETE CHAT =================
function deleteChat(index) {
  if (!confirm("Are you sure you want to delete this chat?")) return;

  sessions.splice(index, 1);
  if (sessions.length === 0) {
    startNewChat();
  } else {
    if (activeSessionIndex >= sessions.length) activeSessionIndex = sessions.length - 1;
    if (activeSessionIndex === index) renderMessages();
  }
  saveCurrentSession();
  renderChatHistory();
}

// ================= UTILS =================
function formatTime(d) {
  return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}

function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}