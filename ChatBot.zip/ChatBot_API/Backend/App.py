# app.py
"""
FastAPI application for AdventureWorks Chatbot
"""

from fastapi import FastAPI, Body
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from typing import List, Dict

from ChatBot import handle_chat

app = FastAPI(title="AdventureWorks Chatbot")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.post("/chat")
async def chat(messages: List[Dict[str, str]] = Body(...)):
    return handle_chat(messages)

# Serve frontend (index.html, etc.)
app.mount("/", StaticFiles(directory="../Frontend", html=True), name="static")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("app:app", host="127.0.0.1", port=8000, reload=True)