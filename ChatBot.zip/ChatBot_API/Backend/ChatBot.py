# chatbot.py
"""
Chatbot logic for AdventureWorks Chatbot
Handles LLM interaction, tool calling, and database execution
"""

import os
import json
from datetime import datetime
from typing import List, Dict

import pandas as pd
from sqlalchemy import create_engine, text
from openai import OpenAI
from dotenv import load_dotenv

# ─── Load environment ────────────────────────────────────────────────────────
load_dotenv()

OPENROUTER_API_KEY = os.getenv("OPENROUTER_API_KEY")

if not OPENROUTER_API_KEY:
    raise ValueError(
        "OPENROUTER_API_KEY not found in .env file.\n"
        "Please add your OpenRouter API key like this:\n"
        "OPENROUTER_API_KEY=sk-or-v1-..."
    )

# ─── OpenRouter client ───────────────────────────────────────────────────────
client = OpenAI(
    api_key=OPENROUTER_API_KEY,
    base_url="https://openrouter.ai/api/v1",
)

client.default_headers.update({
    "HTTP-Referer": "http://localhost:8000",
    "X-Title": "AdventureWorks Chatbot",
})

# ─── Database connection ─────────────────────────────────────────────────────
DB_CONNECTION_STRING = (
    "mssql+pyodbc://@localhost/AdventureWorks2016"
    "?driver=ODBC+Driver+17+for+SQL+Server"
    "&trusted_connection=yes"
)

engine = create_engine(DB_CONNECTION_STRING)

# ─── Schema and examples ─────────────────────────────────────────────────────
schema_description = """
AdventureWorks 2016 OLTP - fictitious bicycle company
Most important tables & relationships:
Person.Person (BusinessEntityID PK, FirstName, LastName, PersonType, ...)
Person.EmailAddress, Person.PersonPhone, Person.BusinessEntityAddress
HumanResources.Employee (BusinessEntityID PK/FK, JobTitle, BirthDate, Gender, HireDate, ...)
HumanResources.Department, HumanResources.EmployeeDepartmentHistory
Production.Product (ProductID PK, Name, ProductNumber, Color, ListPrice, Size, Weight, ProductSubcategoryID, ...)
Production.ProductCategory, Production.ProductSubcategory
Sales.Customer (CustomerID PK, PersonID, StoreID, TerritoryID, AccountNumber)
Sales.SalesOrderHeader (SalesOrderID PK, OrderDate, DueDate, CustomerID, SalesPersonID, TerritoryID, SubTotal, TotalDue, ...)
Sales.SalesOrderDetail (SalesOrderID, ProductID, OrderQty, UnitPrice, UnitPriceDiscount, LineTotal)
Sales.SalesPerson, Sales.SalesTerritory
"""

few_shot_examples = """
Examples - follow this style carefully:
User: How many products are there?
→ We have 504 products in the catalog.
User: Top 5 most expensive products
→ The most expensive products are: Mountain-200 Black, 38 ($2,294.99), Mountain-200 Black, 42 ($2,294.99), ...
User: Best selling products
→ The top selling products by quantity are Mountain-200 Black, Touring-1000 Blue, etc.
User: Total sales by year
→ Total sales were highest in 2014 with approximately $22.4 million, followed by 2013 with $4.9 million.
User: Add a new product named 'Test Bike' with list price $100
→ I've added the new product 'Test Bike' with ID 1001 and list price $100.
User: Update product ID 707 list price to $200
→ Are you sure you want to update product ID 707 to $200? (User: yes) → Updated successfully, 1 row affected.
User: Delete product ID 999
→ Are you sure you want to delete product ID 999? This is permanent. (User: yes) → Deleted successfully, 1 row affected.
"""

# ─── Execution helpers ───────────────────────────────────────────────────────
def execute_query(query: str) -> Dict:
    try:
        with engine.connect() as conn:
            df = pd.read_sql(text(query), conn)
            if len(df) > 300:
                return {
                    "status": "warning",
                    "message": f"Query returned {len(df)} rows (showing first 300)",
                    "data": df.head(300).to_json(orient="records", date_format="iso")
                }
            return {
                "status": "success",
                "data": df.to_json(orient="records", date_format="iso")
            }
    except Exception as e:
        return {
            "status": "error",
            "message": str(e).replace("\n", " ").strip()[:400]
        }

def execute_insert(query: str) -> Dict:
    try:
        with engine.connect() as conn:
            with conn.begin() as trans:
                result = conn.execute(text(query))
                trans.commit()
                return {
                    "status": "success",
                    "affected_rows": result.rowcount,
                    "last_insert_id": result.lastrowid if result.lastrowid else None
                }
    except Exception as e:
        return {
            "status": "error",
            "message": str(e).replace("\n", " ").strip()[:400]
        }

def execute_update(query: str) -> Dict:
    try:
        with engine.connect() as conn:
            with conn.begin() as trans:
                result = conn.execute(text(query))
                trans.commit()
                return {
                    "status": "success",
                    "affected_rows": result.rowcount
                }
    except Exception as e:
        return {
            "status": "error",
            "message": str(e).replace("\n", " ").strip()[:400]
        }

def execute_delete(query: str) -> Dict:
    try:
        with engine.connect() as conn:
            with conn.begin() as trans:
                result = conn.execute(text(query))
                trans.commit()
                return {
                    "status": "success",
                    "affected_rows": result.rowcount
                }
    except Exception as e:
        return {
            "status": "error",
            "message": str(e).replace("\n", " ").strip()[:400]
        }

# ─── Tools definition ────────────────────────────────────────────────────────
tools = [
    {
        "type": "function",
        "function": {
            "name": "execute_sql",
            "description": "Execute a SELECT query on AdventureWorks 2016. Returns JSON results.",
            "parameters": {
                "type": "object",
                "properties": {"query": {"type": "string", "description": "Valid SQL SELECT query"}},
                "required": ["query"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "execute_insert",
            "description": "Execute an INSERT query on AdventureWorks 2016. Returns affected rows and last ID.",
            "parameters": {
                "type": "object",
                "properties": {"query": {"type": "string", "description": "Valid SQL INSERT query"}},
                "required": ["query"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "execute_update",
            "description": "Execute an UPDATE query on AdventureWorks 2016. Returns affected rows.",
            "parameters": {
                "type": "object",
                "properties": {"query": {"type": "string", "description": "Valid SQL UPDATE query"}},
                "required": ["query"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "execute_delete",
            "description": "Execute a DELETE query on AdventureWorks 2016. Returns affected rows.",
            "parameters": {
                "type": "object",
                "properties": {"query": {"type": "string", "description": "Valid SQL DELETE query"}},
                "required": ["query"]
            }
        }
    }
]

# ─── Main chat handling function ─────────────────────────────────────────────
def handle_chat(messages: List[Dict[str, str]]) -> Dict[str, str]:
    current_date = datetime.now().strftime('%Y-%m-%d')
    
    system_prompt = f"""You are a helpful assistant answering questions and performing operations on the AdventureWorks 2016 database.

Current date: {current_date}

Rules - follow strictly:
• For read questions, use execute_sql with SELECT queries - give natural language answers with results
• For add/create, use execute_insert with INSERT queries
• For change/edit, use execute_update with UPDATE queries - ALWAYS ask user for confirmation first (e.g., "Are you sure you want to update X?")
• For remove/delete, use execute_delete with DELETE queries - ALWAYS ask user for confirmation first (e.g., "Are you sure you want to delete X? This is permanent.")
• ONLY generate SELECT/INSERT/UPDATE/DELETE - never DROP/CREATE/ALTER/EXEC/etc.
• Limit UPDATE/DELETE to specific IDs/conditions to avoid mass changes
• Give clear, friendly natural language answers with the results (e.g., "Updated 1 row")
• Format numbers nicely (thousands separators, currency)
• Use markdown tables for multiple rows
• If unclear, ask for clarification

Database schema overview:
{schema_description}

Follow these examples of final answers (do NOT show SQL):
{few_shot_examples}
"""

    full_messages = [{"role": "system", "content": system_prompt}] + messages

    while True:
        response = client.chat.completions.create(
            model="openai/gpt-4o-mini",
            messages=full_messages,
            tools=tools,
            tool_choice="auto",
            temperature=0.0,
            max_tokens=1200,
        )

        message = response.choices[0].message

        if message.tool_calls is None:
            return {"response": message.content or "(no response)"}

        full_messages.append(message.model_dump(exclude_none=True))

        for tool_call in message.tool_calls:
            args = json.loads(tool_call.function.arguments)
            query = args.get("query", "")

            if tool_call.function.name == "execute_sql":
                result = execute_query(query)
            elif tool_call.function.name == "execute_insert":
                result = execute_insert(query)
            elif tool_call.function.name == "execute_update":
                result = execute_update(query)
            elif tool_call.function.name == "execute_delete":
                result = execute_delete(query)
            else:
                result = {"status": "error", "message": "Unknown tool"}

            full_messages.append({
                "role": "tool",
                "tool_call_id": tool_call.id,
                "name": tool_call.function.name,
                "content": json.dumps(result)
            })